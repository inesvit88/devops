#/bin/bash

docker-compose --verbose -f docker-compose-wp-maria-phpmyadmin.yml up -d

