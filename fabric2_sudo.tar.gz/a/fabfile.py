from invoke import task
import os

g_uid = 'inesvit'

def do_setup():
        global g_uid
	g_uid  = str(os.getenv('_opsuser'))

@task(pre=do_setup())
def fab_groups(c):
	c.local('groups ' + g_uid)
@task
def copy_ssh_keys(c):
	print('uid: ' + g_uid)

@task(pre=do_setup())
def list_ssh_keys(c):
	if c.run('ls -al /home/' + g_uid + '/.ssh', warn=True).failed:
		pass

@task(pre=do_setup())
def sudo_whoami(c):
	if c.sudo('whoami', warn=True, pty=True).failed:
		pass
