#!/bin/bash

HOSTSFILE="./hosts"
export _opsuser="$1"; fab2 --prompt-for-sudo-password -H $(cat $HOSTSFILE | tr '\r\n' ',' | rev | cut -c 2- | rev) $2 && unset _opsuser
